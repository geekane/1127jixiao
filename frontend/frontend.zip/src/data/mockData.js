export const operatorData = [
  {
    operator_name: '张三',
    group_name: '客服A组',
    store_count: 10,
    avg_score: 85.5,
    total_salary: 25000.0,
  },
  {
    operator_name: '李四',
    group_name: '客服B组',
    store_count: 8,
    avg_score: 78.2,
    total_salary: 22000.0,
  },
  {
    operator_name: '王五',
    group_name: '客服A组',
    store_count: 12,
    avg_score: 92.0,
    total_salary: 28000.0,
  },
];