import React, { useState, useEffect } from 'react';
import './App.css';
import Sidebar from './components/Sidebar';
import MainContent from './components/MainContent';
import { operatorData } from './data/mockData';

function App() {
  const [operators, setOperators] = useState([]);
  const [selectedOperator, setSelectedOperator] = useState(null);

  useEffect(() => {
    // Simulate fetching data
    setOperators(operatorData);
    if (operatorData.length > 0) {
      setSelectedOperator(operatorData[0]);
    }
  }, []);

  const handleOperatorChange = (operatorName) => {
    const operator = operators.find(op => op.operator_name === operatorName);
    setSelectedOperator(operator);
  };

  const handleRefreshScoreData = () => {
    alert('正在采集经营分数据...');
    // In a real app, you would make an API call here.
    setTimeout(() => {
      alert('经营分数据采集成功！');
    }, 1000);
  };

  const handleRefreshBillData = () => {
    alert('正在采集账单数据...');
    // In a real app, you would make an API call here.
    setTimeout(() => {
      alert('账单数据采集成功！');
    }, 1000);
  };

  const handleRefreshPage = () => {
    window.location.reload();
  };

  return (
    <div className="app-container">
      <Sidebar
        operators={operators}
        selectedOperator={selectedOperator}
        onOperatorChange={handleOperatorChange}
        onRefreshScoreData={handleRefreshScoreData}
        onRefreshBillData={handleRefreshBillData}
        onRefreshPage={handleRefreshPage}
      />
      <MainContent selectedOperator={selectedOperator} />
    </div>
  );
}

export default App;
