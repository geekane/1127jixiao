import React from 'react';

const Sidebar = ({
  operators,
  selectedOperator,
  onOperatorChange,
  onRefreshScoreData,
  onRefreshBillData,
  onRefreshPage,
}) => {
  return (
    <div className="sidebar">
      <h2>数据管理</h2>
      <div className="sidebar-section">
        <label htmlFor="operator-select">选择运营成员:</label>
        <select
          id="operator-select"
          value={selectedOperator ? selectedOperator.operator_name : ''}
          onChange={(e) => onOperatorChange(e.target.value)}
        >
          {operators.map((op) => (
            <option key={op.operator_name} value={op.operator_name}>
              {op.operator_name}
            </option>
          ))}
        </select>
      </div>

      {selectedOperator && (
        <div className="sidebar-section">
          <p><strong>选中人员:</strong> {selectedOperator.operator_name}</p>
          <p><strong>负责分组:</strong> {selectedOperator.group_name}</p>
          <p><strong>门店数量:</strong> {selectedOperator.store_count}家</p>
          <p><strong>平均经营分:</strong> {selectedOperator.avg_score.toFixed(2)}分</p>
          <p><strong>总核销金额:</strong> {selectedOperator.total_salary.toFixed(2)}元</p>
        </div>
      )}

      <div className="sidebar-section">
        <h3>数据采集</h3>
        <div className="button-group">
          <button onClick={onRefreshScoreData}>经营数据</button>
          <button onClick={onRefreshBillData}>账单数据</button>
        </div>
        <button className="refresh-button" onClick={onRefreshPage}>
          刷新页面数据
        </button>
      </div>
    </div>
  );
};

export default Sidebar;